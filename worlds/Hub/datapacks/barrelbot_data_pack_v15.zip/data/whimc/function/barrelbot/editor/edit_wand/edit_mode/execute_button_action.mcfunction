$$(command)
