$forceload add $(x) $(z)
