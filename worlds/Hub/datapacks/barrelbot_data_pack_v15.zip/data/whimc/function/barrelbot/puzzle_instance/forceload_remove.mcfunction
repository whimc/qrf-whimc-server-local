$forceload remove $(x) $(z)
