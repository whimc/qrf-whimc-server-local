data modify storage whimc:storage Items set from block ~ ~ ~ Items
execute unless data storage whimc:storage Items[] run data modify storage whimc:storage Items set from block ~ ~ ~ items
